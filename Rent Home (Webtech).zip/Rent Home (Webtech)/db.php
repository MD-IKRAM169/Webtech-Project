<?php
	$dbhostname = 'localhost';
	$dbusername = 'root';
	$dbpassword = '';
	$dbtablename = 'project';

	$con = mysqli_connect($dbhostname, $dbusername, $dbpassword, $dbtablename);

?>
